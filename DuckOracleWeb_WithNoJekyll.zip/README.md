
# Duck Oracle

**Summon wisdom from the waddling void.**  
A whimsical, web-based oracle that delivers randomized duck prophecies with flair, feathers, and the occasional existential insight.

## Created By:
**Haley Rankin** & Midnight Sparkle (your friendly neighborhood AI companion)

## Features:
- Delightfully random duck responses
- Animated duck image for extra drama
- Simple, clean interface (with soul)
- Easter egg console log for the curious

## How to Use:
1. Open the web page.
2. Click "Summon the Duck."
3. Receive your duck wisdom.
4. Reflect. Quack. Repeat.

## Live Demo:
(Coming soon to GitHub Pages)

## Project Files:
- `index.html` – Main structure of the oracle
- `style.css` – Quacktastic styling
- `script.js` – Logic, duck messages, and secret code signature

## License:
Open source — share it, remix it, add more ducks.

---

*“You are the bread you've been waiting for.” – The Duck Oracle*
